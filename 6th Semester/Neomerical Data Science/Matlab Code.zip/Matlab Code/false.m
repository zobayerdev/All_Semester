function [ Y ] = false( x )
    Y = x*exp(x)-cos(x);
end

